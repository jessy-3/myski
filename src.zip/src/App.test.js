import { render, screen } from '@testing-library/react';
import App from './App';

test('renders learn react link', () => {
  render(<App />);
  const linkElement = screen.getByText(/learn react/i);
  expect(linkElement).toBeInTheDocument();
});

describe('my function or component', () => {
  test('does the following', () => {
    // Magic happens here
  });
 });

 describe('formatUserName function', () => {
  test('formatUserName adds @ at the beginning of the username', () => {
    expect(formatUserName('jc')).toBe('@jc');
  });
 });