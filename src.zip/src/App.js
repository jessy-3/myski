import Header from './components/Header';
import Footer from './components/Footer';
import ResortView from './components/ResortView';

function App() {
  return (
    <>
      <Header />
      <ResortView />
      <Footer />
    </>
  );
}

export default App;