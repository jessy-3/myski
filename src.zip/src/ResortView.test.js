import { render, screen } from '@testing-library/react';
import ResortView from './components/ResortView';

   describe('App component', () => {
    test('it renders', () => {
      render(<ResortView />);
   
   
      expect(screen.getByText('Users:')).toBeInTheDocument();
    });
   })