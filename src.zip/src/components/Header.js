import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
// import Button from '@mui/material/Button';
// import AnalyticsIcon from '@mui/icons-material/Analytics';

export default function HeadBar() {
  return (  
      <AppBar position="fixed" sx={{ flexGrow: 1, backgroundColor:'#88287f', height:64}}>
        <Toolbar>
          {/* <AnalyticsIcon sx={{ display: { xs: 'none', md: 'flex' }, mr: 1, fontSize:'3rem' }} /> */}
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            Most Popular Ski Resorts
          </Typography>
          {/* <Button color="inherit">Login</Button> */}
        </Toolbar>
      </AppBar>   
  );
}