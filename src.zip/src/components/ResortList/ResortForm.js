import React from 'react';

import {resorts} from '../../Resorts';

const last_id = resorts[resorts.length-1].id;
console.log("Enter ResortForm");

export default class ResortForm extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        name: '',
        location: '',
        num_skiruns: 10,
        cur_id: last_id
    };
  
      this.handleChange = this.handleChange.bind(this);
      this.handleSubmit = this.handleSubmit.bind(this);
    }
  
    handleChange(event) {
        switch(event.target.id){
            case 'name': 
                this.setState({name: event.target.value});
                break;
            case 'location': 
                this.setState({location: event.target.value});
                break;
            case 'num_skiruns': 
                this.setState({num_skiruns: event.target.value});
                break;
            default:
                console.log("Error: handleChange, no such input id");
        }
    }
  
    handleSubmit(event) {
        console.log("ResortForm sumbit event: ",event.target);
        var newResortItem = {
            id: this.state.cur_id+1, 
            name: this.state.name, 
            location: this.state.location , 
            num_skiruns: this.state.num_skiruns
        };
        resorts.push(newResortItem);
        event.preventDefault();
    }
  
    render() {
        console.log("Render ResortForm")
      return (
        <form onSubmit={this.props.onSubmit}>
            <label htmlFor="name">Name:</label><br/>
            <input type="text" value={this.state.name} id="name" onChange={this.handleChange} /><br/>
            <label htmlFor="location">Location:</label><br/>
            <input type="text" value={this.state.location} id="location" onChange={this.handleChange} /><br/>
            
            <label htmlFor="num_skiruns">Number of Ski Runs:</label><br/>
            <input type="number" value={this.state.num_skiruns} id="num_skiruns" onChange={this.handleChange} /><br/><br/>

          <input type="submit" value="Creat" />
        </form>
      );
    }
  }
  

  