// import {resorts} from '../../Resorts';
import styles from './ResortList.module.css';

import ResortItem from './ResortItem';

export default function ResortList(props) {
    const {resorts}=props;
    const content = resorts.map((el) =>
      <div key={el.id}>
        <h3>{el.name}</h3>
        <p>{el.location}</p>
        <p>{el.num_skiruns}</p>
        <ResortItem item={el} handleEdit={props.editItem} handleDelete={props.deleteItem}/>
      </div>
    );
    return (
      <div className={styles.skiList}>
        {content}
      </div>
    );
  }

  