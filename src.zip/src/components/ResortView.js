import React from 'react';
import Box from '@mui/material/Box';

import ResortList from './ResortList/ResortList';
import ResortForm from './ResortList/ResortForm'

//import the resorts data
import {resorts} from '../Resorts';
const last_id = resorts[resorts.length-1].id;
console.log("Enter Main last resortList item id is ",last_id);

const sideWidth = 400;


export default class ResortView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      resortsArr: resorts,
      name: '',
      location: '',
      num_skiruns: 10,
      cur_id: last_id
    };
    this.handleAdd = this.handleAdd.bind(this);
    this.editItem = this.editItem.bind(this);
    this.deleteItem = this.deleteItem.bind(this);
  }

  //Handle the Add event in ResortForm to add a new ski resort in the list
  handleAdd(event) {
    // console.log("handleAdd event: ",parseInt(event.target.num_skiruns.value));
    // console.log("cur_id ", this.state.cur_id);
    var newResortItem = {
        id: this.state.cur_id+1, 
        name: event.target.name.value, 
        location: event.target.location.value, 
        num_skiruns: parseInt(event.target.num_skiruns.value)
      };
    resorts.push(newResortItem);
    // console.log("newResortItem ",resorts);
 
    this.setState({
      resortsArr: resorts,
      cur_id: this.state.cur_id+1
    });
    // console.log("cur_id ", this.state.cur_id+1);
    event.preventDefault();
  }

  //Handle the Edit event from ResortItem
  editItem(itemID){
    console.log("edit itemID ", itemID)
    
  }

  //Handle the Delete event from ResortItem
  deleteItem(itemID){
    console.log("delete itemID ",itemID);
    // resorts.splice(itemID-1,1);
    delete resorts[itemID-1];
    this.setState({
      resortsArr: resorts
    });
  }

  render(){
    console.log("Render Main")
    return (
      <Box 
        sx={{
          minHeight: {
            xs: 200,  
            md: 700,  
          },
          marginTop:{ xs: 6, sm: 8, lg: 8 }
        }}
      >
        <Box component="main" 
            sx={{
              minHeight: {
                xs: 200,  
                md: 700,  
              },
              marginTop:{ xs: 6, sm: 8, lg: 8 },
              marginBottom:{ xs: 4, sm: 7, lg: 7 },
              display: 'flex',
              minWidth: {xs:`calc(100% - ${sideWidth*0.5}px)`, sm:`calc(100% - ${sideWidth*0.6}px)`, md: `calc(100% -  ${sideWidth}px)`},
              mr: {xs:`${sideWidth*0.5}px`, sm:`${sideWidth*0.6}px`, md: `${sideWidth}px`}
            }}
          >
            <Box component="section" 
                sx={{
                    borderStyle:'solid',
                    marginTop:0,
                    marginRight:2,
                    marginLeft:{ xs: 2, sm: 4, lg: 8 },
                    paddingTop: 1,
                    paddingLeft: 2,
                    paddingRight: 2,
                    flexGrow: 1,
                    backgroundColor: '#fff'
                }}
                >Main Content Area for charts
                <ResortList 
                  resorts={this.state.resortsArr} 
                  editItem={this.editItem} 
                  deleteItem={this.deleteItem}
                  />
            </Box>
            {/* <Box component="aside"
                sx={{
                    borderStyle:'solid',
                    paddingTop: 1,
                    flexGrow: 1
                }}
            >
              Aside For Detailed Info
            </Box> */}
        </Box>
        <Box component="aside"
        sx={{
            borderStyle:'solid',
            width:{xs:sideWidth*0.5, sm:sideWidth*0.6, md:sideWidth-35},
            height:'100%',
            position:'fixed',
            top:64,
            right:0,
            backgroundColor: '#fff',
            paddingTop: 1,
            paddingLeft: 2,
            paddingRight: 2,
        }}
    >
      Aside For Detailed Info
        <ResortForm onSubmit={this.handleAdd}/>
        </Box>
      </Box>
    );
  }
}