export const resorts = [
    {id: 1, name: 'Ski Resort 1', location: 'Location 1', num_skiruns: 11},
    {id: 2, name: 'Ski Resort 2', location: 'Location 2', num_skiruns: 12},
    {id: 3, name: 'Ski Resort 3', location: 'Location 3', num_skiruns: 13},
    {id: 4, name: 'Ski Resort 4', location: 'Location 4', num_skiruns: 14},
    {id: 5, name: 'Ski Resort 5', location: 'Location 5', num_skiruns: 15},
    {id: 6, name: 'Ski Resort 6', location: 'Location 6', num_skiruns: 16},
    {id: 7, name: 'Ski Resort 7', location: 'Location 7', num_skiruns: 17},
    {id: 8, name: 'Ski Resort 8', location: 'Location 8', num_skiruns: 18},
    {id: 9, name: 'Ski Resort 9', location: 'Location 9', num_skiruns: 19},
    {id: 10, name: 'Ski Resort 10', location: 'Location 10', num_skiruns: 10},
  ];