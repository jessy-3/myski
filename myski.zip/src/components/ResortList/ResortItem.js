import * as React from 'react';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';

export default function ResortItem(props) {
  return (
    <Card 
    sx={{ width: 578}}
    > 
      <CardMedia
        sx={{ 
          // height: 430,
          height: {
            xs: 200,
            sm: 265,  
            md: 430,  
          },
        }}
        image="./images/resort1.jpeg"
        title={props.item.name}
      />
      <CardContent>
        <Typography gutterBottom variant="h5" component="div">
          {props.item.name}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Location: {props.item.location}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Number of Ski Runs: {props.item.num_skiruns}
        </Typography>
      </CardContent>
      <CardActions>
        <Button size="small">Edit</Button>
        <Button size="small">Delete</Button>
      </CardActions>
    </Card>
  );
}

export  function ResortListItem(props) {
  return (
    <div >
      <div className="resort-list-item-header">
        <h3>{props.item.name}</h3>
      </div>
      <div className="resort-list-item-content">
        <div className="resort-list-item-img-wrap">
          <img src="" alt="" title=""/>
        </div>
        <div className="resort-list-item-text">
          <table className="infor-table">
            <tbody>
              <tr>
                <td>
                  Name
                </td>
                <td>
                  {props.item.name}
                </td>
              </tr>
              <tr>
                <td>
                  Location
                </td>
                <td>
                  {props.item.location}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}