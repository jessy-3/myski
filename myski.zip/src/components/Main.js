import * as React from 'react';
import Box from '@mui/material/Box';

import ResortList from './ResortList/ResortList';
import ResortForm from './ResortList/ResortForm'

const sideWidth = 400;

export default function Main() {
  return (
    <Box 
      sx={{
        minHeight: {
          xs: 200,  
          md: 700,  
        },
        marginTop:{ xs: 6, sm: 8, lg: 8 }
      }}
    >
      <Box component="main" 
          sx={{
            minHeight: {
              xs: 200,  
              md: 700,  
            },
            marginTop:{ xs: 6, sm: 8, lg: 8 },
            display: 'flex',
            minWidth: {xs:`calc(100% - ${sideWidth*0.5}px)`, sm:`calc(100% - ${sideWidth*0.6}px)`, md: `calc(100% -  ${sideWidth}px)`},
            mr: {xs:`${sideWidth*0.5}px`, sm:`${sideWidth*0.6}px`, md: `${sideWidth}px`}
          }}
        >
          <Box component="section" 
              sx={{
                  borderStyle:'solid',
                  marginTop:0,
                  marginRight:2,
                  marginLeft:{ xs: 2, sm: 4, lg: 8 },
                  paddingTop: 1,
                  paddingLeft: 2,
                  paddingRight: 2,
                  flexGrow: 1,
                  backgroundColor: '#fff'
              }}
              >Main Content Area for charts
              <ResortList />
          </Box>
          {/* <Box component="aside"
              sx={{
                  borderStyle:'solid',
                  paddingTop: 1,
                  flexGrow: 1
              }}
          >
            Aside For Detailed Info
          </Box> */}
      </Box>
      <Box component="aside"
      sx={{
          borderStyle:'solid',
          width:{xs:sideWidth*0.5, sm:sideWidth*0.6, md:sideWidth-35},
          height:'100%',
          position:'fixed',
          top:64,
          right:0,
          backgroundColor: '#fff',
          paddingTop: 1,
          paddingLeft: 2,
          paddingRight: 2,
      }}
  >
    Aside For Detailed Info
      <ResortForm />
      </Box>
    </Box>
  );
}